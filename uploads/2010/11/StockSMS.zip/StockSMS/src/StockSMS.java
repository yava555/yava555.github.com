
public class StockSMS {
	
	public static void main(String[] args) {
		MailReceiver receiver=new MailReceiver();
		receiver.receiveMails();
	}
}
