import java.util.Properties;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;
import javax.mail.internet.MimeMessage;

import org.hijava.httpbot.HttpBot;
import org.hijava.util.MailUtil;
import org.hijava.util.Utils;

/**
 * �ʼ����մ���
 * @author yava
 */
public class MailReceiver {
	
	/**
	 * ѭ�������ʼ�
	 */
	public void receiveMails(){
		while(true){
			receiveMail();
			Utils.sleep(1*60);
		}
	}

	public void receiveMail() {
		
		Properties props = new Properties();
		props.setProperty("mail.smtp.host", "smtp.126.com");
		props.setProperty("mail.smtp.auth", "true");
		Session session = Session.getDefaultInstance(props,null);
		//TODO �����滻�ʼ���ַ
		URLName urlname = new URLName("pop3","pop.126.com",110,null,"email address","password");
		
		String result="";
		try {
			Store store = session.getStore(urlname);
			store.connect();
			Folder folder = store.getFolder("INBOX");
			folder.open(Folder.READ_WRITE);
			Message msgs[] = folder.getMessages();
			int count = msgs.length;
			MailParser rm = null;
			for(int i=0;i<count;i++){
				rm = new MailParser((MimeMessage) msgs[i]);
				String subject=rm.getSubject().trim();
				String from=rm.getFrom();
				String stockNumber=null;
				if(subject.matches("^\\d{6}$")){
					String first2Letter=subject.substring(0,2);
					if(first2Letter.equals("60")||first2Letter.equals("51")){
						stockNumber="sh"+subject;
						result=getStockPrice(stockNumber);
					}
					else if(first2Letter.equals("00")){
						stockNumber="sz"+subject;
						result=getStockPrice(stockNumber);
					}
					else{
						result="��Ʊ����������˶Ժ��ٲ�ѯ��";
					}
				}
				else{
					result="��Ʊ����������˶Ժ��ٲ�ѯ��";
				}
				//�����ʼ�
				MailUtil.sendMail(result,"hijava.org", from);
				msgs[i].setFlag(Flags.Flag.DELETED,true);
			}
			folder.close(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private String getStockPrice(String stockNumber) {
		String url="http://hq.sinajs.cn/list="+stockNumber;
		HttpBot bot=new HttpBot();
		bot.setEncoding("GBK");
		String content= bot.doGet(url);
		content=content.substring(content.indexOf("\"")+1);
		String[] result=content.split(",");
		if(result.length>5){
			StringBuilder stockInfo=new StringBuilder();
			stockInfo.append(result[0]+"  ");
			stockInfo.append("��ǰ�۸�"+result[3]+"  ");
			stockInfo.append("���տ��̼ۣ�"+result[1]+"  ");
			stockInfo.append("�������̼ۣ�"+result[2]+"  ");
			stockInfo.append("������߼ۣ�"+result[4]+"  ");
			stockInfo.append("������ͼۣ�"+result[5]+"  ");
			return stockInfo.toString();
		}else{
			return "��ȡ���ݳ�����";
		}
	}
	
}
